using System;
using System.Windows.Forms;
using System.Windows.Input;
using GlobalHotKey;
using ModifierKeys = System.Windows.Input.ModifierKeys;

namespace NinjaSnipp.Services
{
  public class HotkeyService : IDisposable
  {
    private readonly HotKeyManager _hotKeyManager;
    private int _registeredHotKeyId = 0;
    
    public event EventHandler<HotKeyEventArgs>? HotkeyPressed;
    
    public HotkeyService()
    {
      _hotKeyManager = new HotKeyManager();
      _hotKeyManager.KeyPressed += HotKeyManager_KeyPressed;
    }
    
    private void HotKeyManager_KeyPressed(object? sender, KeyPressedEventArgs e)
    {
      HotkeyPressed?.Invoke(this, new HotKeyEventArgs { HotKey = e.HotKey });
    }
    
    public bool RegisterHotKey(Key key, ModifierKeys modifiers)
    {
      try
      {
        var hotKey = new GlobalHotKey.HotKey(key, modifiers);
        _registeredHotKeyId++;
        _hotKeyManager.Register(hotKey);
        return true;
      }
      catch (Exception ex)
      {
        Console.WriteLine($"Error registering hotkey: {ex.Message}");
        return false;
      }
    }
    
    public void UnregisterAllHotKeys()
    {
      _hotKeyManager.UnregisterAll();
    }
    
    public void Dispose()
    {
      UnregisterAllHotKeys();
      _hotKeyManager.Dispose();
    }
  }
  
  public class HotKeyEventArgs : EventArgs
  {
    public GlobalHotKey.HotKey HotKey { get; set; } = new GlobalHotKey.HotKey(Key.None, ModifierKeys.None);
  }
}